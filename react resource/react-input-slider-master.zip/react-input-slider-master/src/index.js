export default from './slider';

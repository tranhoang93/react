module.exports = {
  presets: ['swiftcarrot']
};

# Changelog

## [Unreleased]

- add support for rendering marks on slider

## [5.1.4]

- add type definition file

## [5.1.3]

- add `props.dragStart` support

## [5.1.2]

- format changelog

## [5.1.1]

- event disabled fix

## [5.1.0]

- add `props.disabled` and `styles.disabled` support

## [5.0.7]

- `sideEffects: false` in `package.json` for webpack tree shaking

## [5.0.6]

- Fix wrong thumb's top position calculation
